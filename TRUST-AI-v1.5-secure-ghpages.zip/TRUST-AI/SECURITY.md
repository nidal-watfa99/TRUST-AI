# حماية TRUST AI على GitHub Pages

## الواقع التقني

**GitHub Pages لا يدعم رؤوس HTTP مخصصة** (مثل `Content-Security-Policy` أو `X-Frame-Options` كاستجابة خادم).

ما تم تطبيقه داخل المشروع:
- سياسة CSP عبر وسم `<meta>` في `index.html`
- `Referrer-Policy` عبر meta
- مفاتيح API في ذاكرة الجلسة فقط (لا تُرفع لأي خادم TRUST AI)
- لا مكتبات طرف ثالث غير خطوط Google
- Service Worker يخزّن الأصول الثابتة فقط

## خطوات إلزامية على GitHub

1. **تفعيل 2FA** على حساب GitHub.
2. المستودع: Settings → Pages → Source = GitHub Actions (لديك `deploy.yml` جاهز).
3. لا ترفع مفاتيح API أو ملف `.env` حقيقي أبداً.
4. Settings → Branches → حماية فرع `main` (Prevent force push إن أمكن).

## HTTPS

GitHub Pages يوفّر HTTPS تلقائياً لنطاق:
`https://USERNAME.github.io/REPO/`

وللنطاق المخصص: Settings → Pages → Custom domain → فعّل **Enforce HTTPS**.

## حماية أقوى (موصى بها): Cloudflare أمام GitHub Pages

مجاني ويعطيك الرؤوس الأمنية الحقيقية:

1. أنشئ حساباً على [cloudflare.com](https://cloudflare.com).
2. أضف نطاقك (أو نطاقاً فرعياً) وغيّر الـ Nameservers.
3. سجّل سجلاً `CNAME` يشير إلى `USERNAME.github.io` مع تفعيل البروكسي (السحابة البرتقالية).
4. في Cloudflare → **Rules** → **Transform Rules** → **Modify Response Header** أضف:

| Header | Value |
|--------|--------|
| `Content-Security-Policy` | نفس سياسة CSP الموجودة في `index.html` (سطر واحد) |
| `X-Frame-Options` | `DENY` |
| `X-Content-Type-Options` | `nosniff` |
| `Referrer-Policy` | `strict-origin-when-cross-origin` |
| `Permissions-Policy` | `camera=(), geolocation=(), interest-cohort=()` |
| `Strict-Transport-Security` | `max-age=31536000; includeSubDomains; preload` |

5. SSL/TLS → mode: **Full**.

ملف مرجعي للرؤوس موجود في المشروع: `headers-cloudflare.txt`.

## ما لا يمكن منعه من جهة التطبيق وحده

- جهاز المستخدم المخترق أو إضافة متصفح خبيثة
- لصق المستخدم لمفتاحه في مكان عام
- حدود مزودي الذكاء الاصطناعي (Groq / Google / OpenAI / OpenRouter)

## الإبلاغ عن ثغرة

تواصل مع المطوّر عبر البريد المذكور في README — دون نشر تفاصيل الاستغلال علناً قبل الإصلاح.
