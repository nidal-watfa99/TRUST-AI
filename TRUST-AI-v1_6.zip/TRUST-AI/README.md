# TRUST AI v1.1

**تحقق قبل أن تثق. / Verify before you trust.**

منصة موثوقة للسلامة الرقمية تساعد المستخدم على تقييم الرسائل المشبوهة والروابط ولقطات الشاشة قبل اتخاذ قرار خطير على الإنترنت.

A trusted digital safety platform that helps users assess suspicious messages, links, and screenshots before making risky online decisions.

### v1.6 updates
- **العميل (Client)** — شاشة كاملة لتحليل الحدث: تقبل الروابط والصور (حتى 4) والأسماء والأخبار والرسائل والملفات النصية، وتعرض: الحكم والمقياس، شرح الحدث ونوعه وكيف يعمل، التحذيرات مرتبة بالخطورة، رسوم بيانية (مقياس، رادار 6 محاور، حلقة حصص الفئات، أعمدة خطورة كل جملة، مستويات المحاور، مؤشرات المصداقية)، العناصر المستخرجة، فحص الروابط، الادعاءات، أدوات تحقق رسمية، وما يجب فعله وتجنبه.
- **لوحة النماذج** تحل محل نافذة الإعدادات: تبويبات المزوّدين، بطاقات النماذج، خانة المفتاح (إظهار/لصق/تحقق من الصيغة) والرابط الرسمي لإنشاء المفتاح مع نسخه.
- ملفات جديدة: `js/client.js` (الواجهة)، `js/client-engine.js` (محرك محلي نقي)، `js/client-data.js` (الأدلة والنصوص)، `tests/client-engine.test.js`.
- لم تُحذف أي ميزة سابقة (التحليل الأساسي، التقرير التفصيلي، الصوت، السجل، الوضع الليلي/كبار السن، PWA…).

### v1.1 updates
- صفحة شرح موثوق للمنهجية (About) — طبقات التحليل، الأوزان، الخصوصية والحدود
- شعار أنيق لامع + أيقونة سطح المكتب عند التثبيت (PWA manifest)
- تواصل مع المطوّر عبر البريد: nidalwatfa99@gmail.com
- إدخال صوتي (ميكروفون) عبر Web Speech API

---

## Dual-layer architecture

| Layer | Mode | Requirement |
|-------|------|-------------|
| **1 — Offline** | Rule-based Risk Engine | None — works fully offline |
| **2 — AI Client** | Optional LLM enhancement + vision | User-provided free/paid API key |

Keys stay in browser memory only (password field). Never hardcoded. Never sent to any TRUST AI server.

---

## Features

- **Text & URL analysis** with transparent risk score 0–100
- **Category breakdown** with points, max weights, and percentages
- **Link heuristics**: suspicious TLDs, brand spoofing, IP hosts, shorteners, punycode
- **Screenshot upload** — full vision analysis when a vision model is connected
- **Arabic (RTL) + English (LTR)** with instant switcher
- **Free models** with official key links: Groq (Llama), Google Gemini, OpenRouter
- **Paid models**: OpenAI GPT-4o / GPT-4o mini
- **Demo examples** (8 fictional scenarios)
- **Privacy-first**: no accounts, no permanent storage of user content
- Mobile-first professional dark UI with risk gauge, tables, and warnings
- About page with transparent methodology explanation
- Voice input (microphone) via Web Speech API
- Developer feedback email (nidalwatfa99@gmail.com)
- PWA installable with desktop icon and elegant logo

---

## Risk scoring (transparent)

| Category              | Max points |
|-----------------------|------------|
| Urgency / pressure    | 15         |
| Impersonation         | 20         |
| Money request         | 20         |
| Sensitive info request| 20         |
| Link indicators       | 15         |
| Unrealistic offers    | 5          |
| Social engineering    | 5          |

| Score   | Level                    |
|---------|--------------------------|
| 0–24    | Low risk                 |
| 25–49   | Medium risk              |
| 50–74   | High risk                |
| 75–100  | Severe risk              |
| n/a     | Needs further verification |

**Important:** Results are risk assessments, not absolute verdicts. No system can guarantee 100% safety.

---

## Quick start

No build step. Open in any modern browser:

```bash
cd trust-ai
npx serve .
# or
python3 -m http.server 8080
```

Open `http://localhost:8080`.

---

## Project structure

```
trust-ai/
├── index.html
├── manifest.json        # PWA — desktop install icon
├── css/styles.css
├── assets/
│   ├── logo.svg
│   ├── icon-192.svg
│   └── icon-512.svg
├── js/
│   ├── app.js           # UI controller + voice + about
│   ├── risk-engine.js   # Offline rule engine
│   ├── ai-provider.js   # Optional AI layer + free models
│   ├── i18n.js          # AR / EN
│   └── examples.js      # Demo scenarios
├── tests/risk-engine.test.js
├── .env.example
└── README.md
```

---

## Enabling AI (optional)

1. Open **Settings** (gear icon)
2. Choose a free model (e.g. Groq Llama or Gemini Flash)
3. Get a key from the official link shown in the list
4. Paste the key (field is type=password, session-only)
5. Click **Save & enable** then **Test connection**

Supported free providers:
- Groq — https://console.groq.com/keys (Llama 3.3, Mixtral)
- Google AI Studio — https://aistudio.google.com/apikey (Gemini 1.5 Flash / Pro, vision)
- OpenRouter — https://openrouter.ai/keys (free models)

---

## Running tests

```bash
node tests/risk-engine.test.js
node tests/client-engine.test.js
```

Requires Node.js 18+.

---

## Privacy

- No user accounts
- No permanent storage of messages, images, passwords, OTPs, or banking data
- API keys held in memory only; input field cleared after save
- Temporary image previews revoked from memory when removed
- No analytics collecting message content

---

## License

Open foundation for digital trust and safety.

**TRUST AI** — a calm, reliable companion that helps you pause before a digital decision that could cause harm.
