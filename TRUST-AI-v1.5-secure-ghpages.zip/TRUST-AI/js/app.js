/**
 * TRUST AI v1.0 — Application controller
 * Dual-layer: offline Risk Engine + optional AI client
 */

import { analyze, detectSensitivePaste } from "./risk-engine.js";
import {
  initAIProvider,
  clearAIProvider,
  isAIAvailable,
  isVisionAvailable,
  getAIStatus,
  getFreeModels,
  analyzeWithAI,
  analyzeImageWithAI,
  testConnection,
} from "./ai-provider.js";
import { initI18n, setLang, getLang, t, applyTranslations } from "./i18n.js";
import { EXAMPLES } from "./examples.js";
import { renderSourceReport } from "./source-report.js";

const HISTORY_KEY = "trustai_history";
const HISTORY_MAX = 20;
const USAGE_KEY = "trustai_usage";

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

let currentImageDataUrl = null;
let lastResult = null;
let lastText = "";

// ── Init ─────────────────────────────────────────────────────────────────

document.addEventListener("DOMContentLoaded", () => {
  initI18n();
  initTheme();
  initElderly();
  bindEvents();
  bindImageFallbacks();
  bindSensitiveWatch();
  updateAIStatusUI();
  populateModelSelect();
  setLiveAlertsIdle();
  initInstallPrompt();
  syncLangButtons();
  updateModeBanner();
});

function bindEvents() {
  $("#lang-ar")?.addEventListener("click", () => switchLang("ar"));
  $("#lang-en")?.addEventListener("click", () => switchLang("en"));

  $("#btn-theme")?.addEventListener("click", toggleTheme);
  $("#btn-share")?.addEventListener("click", shareApp);
  $("#btn-install")?.addEventListener("click", triggerInstall);
  $("#btn-elderly")?.addEventListener("click", toggleElderly);
  $("#btn-history")?.addEventListener("click", openHistory);
  $("#history-close")?.addEventListener("click", closeHistory);
  $("#history-backdrop")?.addEventListener("click", closeHistory);
  $("#btn-clear-history")?.addEventListener("click", clearHistory);
  $("#btn-copy-result")?.addEventListener("click", copyResult);
  $("#btn-share-result")?.addEventListener("click", shareResult);
  $("#btn-print-result")?.addEventListener("click", printResult);

  $("#btn-analyze")?.addEventListener("click", onAnalyze);
  $("#btn-upload")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $("#file-input")?.click(); }
  });
  $("#file-input")?.addEventListener("change", onFileSelected);
  $("#btn-remove-image")?.addEventListener("click", removeImage);
  $("#btn-example")?.addEventListener("click", openExamples);
  $("#btn-settings")?.addEventListener("click", openSettings);
  $("#btn-about")?.addEventListener("click", openAbout);
  $("#btn-about-back")?.addEventListener("click", resetToHome);
  $("#btn-again")?.addEventListener("click", resetToHome);
  $("#btn-source")?.addEventListener("click", openSourceReport);
  $("#btn-source-back")?.addEventListener("click", () => { showView("result"); window.scrollTo({ top: 0 }); });
  $("#btn-source-new")?.addEventListener("click", resetToHome);
  $("#btn-back")?.addEventListener("click", resetToHome);
  $("#btn-mic")?.addEventListener("click", toggleVoiceInput);

  // LIVE alert lights — tap to explain signal meaning
  $$(".alert-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const level = btn.dataset.level;
      const msgs = {
        low: { ar: "🟢 أخضر — خطر منخفض / آمن نسبياً", en: "🟢 Green — Low risk / relatively safe" },
        info: { ar: "🔵 أزرق — مراقبة / تحليل جارٍ أو بيانات غير كافية", en: "🔵 Blue — Monitoring / analyzing or insufficient data" },
        high: { ar: "🟠 برتقالي — تحذير مرتفع — انتبه ولا تتسرع", en: "🟠 Orange — High warning — pause and verify" },
        severe: { ar: "🔴 أحمر — خطر شديد — لا تضغط ولا تدفع ولا تشارك بيانات", en: "🔴 Red — Severe risk — do not click, pay, or share data" },
      };
      const m = msgs[level];
      if (m) showToast(getLang() === "ar" ? m.ar : m.en);
    });
  });

  $("#examples-close")?.addEventListener("click", closeExamples);
  $("#examples-backdrop")?.addEventListener("click", closeExamples);
  $("#settings-close")?.addEventListener("click", closeSettings);
  $("#settings-backdrop")?.addEventListener("click", closeSettings);

  $("#btn-save-ai")?.addEventListener("click", onSaveAI);
  $("#btn-clear-ai")?.addEventListener("click", onClearAI);
  $("#btn-test-ai")?.addEventListener("click", onTestAI);

  $("#input-text")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) onAnalyze();
  });
}

function switchLang(lang) {
  setLang(lang);
  syncLangButtons();
  updateAIStatusUI();
  populateModelSelect();
  if (lastResult) renderResult(lastResult);
  if ($("#view-source")?.classList.contains("active")) openSourceReport();
  updateSourceLabels();
}

function syncLangButtons() {
  const lang = getLang();
  $("#lang-ar")?.classList.toggle("active", lang === "ar");
  $("#lang-en")?.classList.toggle("active", lang === "en");
  $("#lang-ar")?.setAttribute("aria-pressed", lang === "ar");
  $("#lang-en")?.setAttribute("aria-pressed", lang === "en");
}

// ── Analysis ─────────────────────────────────────────────────────────────

async function onAnalyze() {
  const text = ($("#input-text")?.value || "").trim();
  const hasImage = !!currentImageDataUrl;

  if (!text && !hasImage) {
    showToast(t("error_empty"), true);
    return;
  }

  showView("analyzing");
  setLiveAlertsMonitoring();
  await sleep(280);

  try {
    // Layer 1 — always offline
    const engineResult = analyze({ text, hasImage });

    let aiResult = null;
    let finalResult = { ...engineResult, mode: "offline" };

    // Layer 2 — optional AI
    if (isAIAvailable()) {
      if (hasImage && isVisionAvailable()) {
        aiResult = await analyzeImageWithAI(currentImageDataUrl, text);
      } else if (text) {
        aiResult = await analyzeWithAI(text, engineResult);
      }

      if (aiResult && !aiResult.error) {
        // Hybrid: take the higher risk signal, keep full transparency
        const hybridScore = Math.max(engineResult.score < 0 ? 0 : engineResult.score, aiResult.score);
        finalResult = {
          ...engineResult,
          score: hybridScore,
          level: hybridScore <= 24 ? "low" : hybridScore <= 49 ? "medium" : hybridScore <= 74 ? "high" : "severe",
          levelColor: hybridScore <= 24 ? "#22c55e" : hybridScore <= 49 ? "#eab308" : hybridScore <= 74 ? "#f97316" : "#ef4444",
          mode: hasImage && isVisionAvailable() ? "ai-vision" : "hybrid",
          ai: aiResult,
        };
      } else if (aiResult?.error) {
        finalResult.aiError = aiResult.error;
        finalResult.mode = "offline";
      }
    } else if (hasImage && !text) {
      finalResult.reasons = ["image_unavailable"];
      finalResult.score = -1;
      finalResult.level = "unknown";
      finalResult.levelColor = "#94a3b8";
    }

    lastResult = finalResult;
    lastText = text;
    saveToHistory(text, finalResult);
    bumpUsage();
    renderResult(finalResult);
    showView("result");
    showToast(t("analysisDone"));
  } catch (err) {
    console.error(err);
    showToast(t("error_generic"), true);
    setLiveAlertsIdle();
    showView("home");
  }
}

function renderResult(r) {
  const scoreEl = $("#result-score");
  const levelEl = $("#result-level");
  const gaugeEl = $("#risk-gauge");
  const modeEl = $("#result-mode");
  const reasonsEl = $("#result-reasons");
  const actionsEl = $("#result-actions");
  const breakdownEl = $("#result-breakdown");
  const catsEl = $("#result-categories");
  const linksEl = $("#result-links");
  const aiBox = $("#result-ai");
  const disclaimer = $("#result-disclaimer");

  // LIVE signal lights react immediately to risk level
  updateLiveAlerts(r.level, r.score);

  // Score & level
  const displayScore = r.score < 0 ? "—" : r.score;
  if (scoreEl) {
    scoreEl.textContent = displayScore;
    scoreEl.style.color = r.levelColor || "#94a3b8";
  }
  if (levelEl) {
    levelEl.textContent = t(`level_${r.level}`);
    levelEl.style.background = (r.levelColor || "#94a3b8") + "22";
    levelEl.style.color = r.levelColor || "#94a3b8";
    levelEl.style.borderColor = r.levelColor || "#94a3b8";
  }

  // Gauge (SVG circle)
  if (gaugeEl) {
    const pct = r.score < 0 ? 0 : r.score;
    const circ = 2 * Math.PI * 54;
    const offset = circ - (pct / 100) * circ;
    gaugeEl.innerHTML = `
      <svg viewBox="0 0 120 120" class="gauge-svg" aria-hidden="true">
        <circle cx="60" cy="60" r="54" fill="none" stroke="#1e2a3a" stroke-width="10"/>
        <circle cx="60" cy="60" r="54" fill="none" stroke="${r.levelColor || "#94a3b8"}"
          stroke-width="10" stroke-linecap="round"
          stroke-dasharray="${circ}" stroke-dashoffset="${offset}"
          transform="rotate(-90 60 60)" class="gauge-arc"/>
        <text x="60" y="58" text-anchor="middle" class="gauge-score" fill="${r.levelColor || "#94a3b8"}">${displayScore}</text>
        <text x="60" y="76" text-anchor="middle" class="gauge-label" fill="#94a3b8">/ 100</text>
      </svg>`;
  }

  // Mode badge
  if (modeEl) {
    const modeKey = r.mode === "hybrid" || r.mode === "ai-vision" ? "modeHybrid" : r.mode === "ai" ? "modeAI" : "modeOffline";
    modeEl.textContent = t(modeKey);
    modeEl.className = "mode-badge " + (r.mode || "offline");
  }

  // Reasons
  if (reasonsEl) {
    reasonsEl.innerHTML = "";
    (r.reasons || []).forEach((key) => {
      const li = document.createElement("li");
      li.textContent = t(`reason_${key}`) || key;
      reasonsEl.appendChild(li);
    });
    if (!(r.reasons || []).length) {
      const li = document.createElement("li");
      li.textContent = t("action_low");
      reasonsEl.appendChild(li);
    }
  }

  // Actions
  if (actionsEl) {
    actionsEl.innerHTML = "";
    (r.actions || []).forEach((key) => {
      const li = document.createElement("li");
      li.textContent = t(`action_${key}`) || key;
      actionsEl.appendChild(li);
    });
    // AI actions if present
    if (r.ai?.actions?.length) {
      r.ai.actions.forEach((a) => {
        const li = document.createElement("li");
        li.textContent = a;
        li.className = "ai-action";
        actionsEl.appendChild(li);
      });
    }
  }

  // Transparent breakdown table
  if (breakdownEl) {
    const rows = (r.transparent?.breakdown || []).map((b) => `
      <tr>
        <td>${t(`cat_${b.category}`) || b.category}</td>
        <td class="num">${b.points}</td>
        <td class="num">${b.max}</td>
        <td class="num">${b.percentOfMax}%</td>
        <td>
          <div class="mini-bar"><div class="mini-fill" style="width:${b.percentOfMax}%;background:${r.levelColor}"></div></div>
        </td>
      </tr>`).join("");
    breakdownEl.innerHTML = rows
      ? `<table class="data-table" aria-label="${t("breakdownTitle")}">
          <thead><tr>
            <th>${t("categoriesTitle")}</th>
            <th>${t("points")}</th>
            <th>Max</th>
            <th>${t("percentOfMax")}</th>
            <th></th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>`
      : `<p class="muted">${t("action_low")}</p>`;
  }

  // Category percent cards
  if (catsEl) {
    const cats = r.categories || {};
    catsEl.innerHTML = Object.entries(cats)
      .filter(([, v]) => v > 0)
      .map(([k, v]) => {
        const pct = r.categoryPercents?.[k] || 0;
        return `<div class="cat-card">
          <div class="cat-name">${t(`cat_${k}`)}</div>
          <div class="cat-val">${v} <span class="muted">/ ${r.transparent?.weights?.[k] || "?"} (${pct}%)</span></div>
          <div class="cat-bar"><div style="width:${pct}%;background:${r.levelColor}"></div></div>
        </div>`;
      })
      .join("") || "";
  }

  // Links table with flags
  if (linksEl) {
    if (r.links?.length) {
      linksEl.innerHTML = r.links.map((l) => {
        const flagLabels = [];
        if (l.isShortener) flagLabels.push(t("linkFlag_shortener"));
        if (l.isBrandSpoof) flagLabels.push(t("linkFlag_brand_spoof"));
        (l.flags || []).forEach((f) => {
          if (f === "suspicious_tld") flagLabels.push(t("linkFlag_suspicious_tld"));
          if (f === "http_not_https") flagLabels.push(t("linkFlag_http_not_https"));
          if (f.startsWith("typosquat")) flagLabels.push(t("linkFlag_typosquat"));
        });
        const uniq = [...new Set(flagLabels)];
        return `<div class="link-card ${l.score >= 8 ? "link-danger" : l.score >= 4 ? "link-warn" : ""}">
          <div class="link-card-top">
            <strong class="link-host">${escapeHtml(l.host || "—")}</strong>
            <span class="link-score-badge">${t("linkScore")}: ${l.score}</span>
          </div>
          <code class="link-url">${escapeHtml((l.url || "").slice(0, 90))}</code>
          ${uniq.length ? `<ul class="link-flags">${uniq.map((x) => `<li>${escapeHtml(x)}</li>`).join("")}</ul>` : ""}
        </div>`;
      }).join("");
    } else {
      linksEl.innerHTML = `<p class="muted">${t("noLinks")}</p>`;
    }
  }

  // AI box
  if (aiBox) {
    if (r.ai) {
      aiBox.classList.remove("hidden");
      aiBox.innerHTML = `
        <h3>${t("aiSummary")}</h3>
        <p>${escapeHtml(r.ai.summary || "")}</p>
        <div class="ai-meta">
          <span>${t("confidence")}: <strong>${r.ai.confidence ?? "—"}%</strong></span>
          <span>${r.ai.provider || ""} / ${r.ai.model || ""}</span>
        </div>
        ${r.ai.indicators?.length ? `<ul class="ai-indicators">${r.ai.indicators.map((i) =>
          `<li><strong>${escapeHtml(i.category || "")}</strong>: ${escapeHtml(i.detail || "")} (${i.severity ?? ""})</li>`
        ).join("")}</ul>` : ""}`;
    } else if (r.aiError) {
      aiBox.classList.remove("hidden");
      aiBox.innerHTML = `<p class="error-text">${t("connectionFail")}: ${escapeHtml(r.aiError)}</p>`;
    } else {
      aiBox.classList.add("hidden");
      aiBox.innerHTML = "";
    }
  }

  if (disclaimer) disclaimer.textContent = t("disclaimer");
}

// ── Image handling ───────────────────────────────────────────────────────

function onFileSelected(e) {
  const file = e.target.files?.[0];
  if (file) processFile(file);
  e.target.value = "";
}

function processFile(file) {
  const okTypes = ["image/jpeg", "image/png", "image/webp", "image/jpg"];
  const extOk = /\.(jpe?g|png|webp)$/i.test(file.name || "");
  if (!okTypes.includes(file.type) && !(file.type === "" && extOk)) {
    showToast(t("error_image_type"), true);
    return;
  }
  if (file.size > 5 * 1024 * 1024) {
    showToast(t("error_image_size"), true);
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    currentImageDataUrl = reader.result;
    const img = $("#preview-img");
    if (img) img.src = currentImageDataUrl;
    $("#image-preview")?.classList.remove("hidden");
    showToast(t("pasteImageOk"));
  };
  reader.onerror = () => showToast(t("error_generic"), true);
  reader.readAsDataURL(file);
}

function bindImageFallbacks() {
  const card = $(".input-card");
  if (!card) return;
  ["dragenter", "dragover"].forEach((ev) =>
    card.addEventListener(ev, (e) => { e.preventDefault(); card.classList.add("drag-over"); }));
  ["dragleave", "drop"].forEach((ev) =>
    card.addEventListener(ev, (e) => { e.preventDefault(); card.classList.remove("drag-over"); }));
  card.addEventListener("drop", (e) => {
    const f = [...(e.dataTransfer?.files || [])].find((x) => x.type.startsWith("image/") || /\.(jpe?g|png|webp)$/i.test(x.name));
    if (f) processFile(f);
  });
  document.addEventListener("paste", (e) => {
    const items = [...(e.clipboardData?.items || [])];
    const item = items.find((i) => i.type.startsWith("image/"));
    const f = item?.getAsFile();
    if (f) {
      e.preventDefault();
      processFile(f);
      return;
    }
    // Also accept files from clipboard on some mobile browsers
    const files = [...(e.clipboardData?.files || [])];
    const imgFile = files.find((x) => x.type.startsWith("image/"));
    if (imgFile) {
      e.preventDefault();
      processFile(imgFile);
    }
  });
}

function removeImage() {
  currentImageDataUrl = null;
  $("#image-preview")?.classList.add("hidden");
  const img = $("#preview-img");
  if (img) {
    if (img.src.startsWith("blob:")) URL.revokeObjectURL(img.src);
    img.src = "";
  }
  const fi = $("#file-input");
  if (fi) fi.value = "";
}

// ── Settings / AI ────────────────────────────────────────────────────────

const PROVIDER_ICONS = {
  groq: `<svg class="model-icon" viewBox="0 0 24 24" width="28" height="28" aria-hidden="true"><rect width="24" height="24" rx="6" fill="#f55036"/><text x="12" y="16" text-anchor="middle" fill="#fff" font-size="9" font-weight="700" font-family="system-ui">G</text></svg>`,
  gemini: `<svg class="model-icon" viewBox="0 0 24 24" width="28" height="28" aria-hidden="true"><rect width="24" height="24" rx="6" fill="#4285F4"/><path d="M12 4l2.5 5.5L20 11l-5.5 2.5L12 19l-2.5-5.5L4 11l5.5-2.5L12 4z" fill="#fff"/></svg>`,
  openrouter: `<svg class="model-icon" viewBox="0 0 24 24" width="28" height="28" aria-hidden="true"><rect width="24" height="24" rx="6" fill="#6366f1"/><path d="M7 12h10M12 7v10" stroke="#fff" stroke-width="2.2" stroke-linecap="round"/></svg>`,
  openai: `<svg class="model-icon" viewBox="0 0 24 24" width="28" height="28" aria-hidden="true"><rect width="24" height="24" rx="6" fill="#10a37f"/><circle cx="12" cy="12" r="5.5" fill="none" stroke="#fff" stroke-width="1.8"/><circle cx="12" cy="12" r="2" fill="#fff"/></svg>`,
};

function populateModelSelect() {
  const sel = $("#ai-model");
  if (!sel) return;
  sel.innerHTML = "";
  getFreeModels().forEach((m) => {
    const opt = document.createElement("option");
    opt.value = m.id;
    const badge = m.free ? ` ★ ${t("badgeFree")}` : ` ⚡ ${t("badgePaid")}`;
    opt.textContent = m.name + badge;
    sel.appendChild(opt);
  });

  const list = $("#free-models-list");
  if (!list) return;
  list.innerHTML = getFreeModels()
    .map((m) => {
      const icon = PROVIDER_ICONS[m.provider] || PROVIDER_ICONS.groq;
      const badges = [];
      if (m.free) badges.push(`<span class="model-badge free">${t("badgeFree")}</span>`);
      else badges.push(`<span class="model-badge paid">${t("badgePaid")}</span>`);
      if (m.vision) badges.push(`<span class="model-badge vision">${t("badgeVision")}</span>`);
      return `
        <li class="model-card ${m.free ? "is-free" : "is-paid"}">
          <div class="model-card-left">
            ${icon}
            <div class="model-card-info">
              <strong class="model-card-name">${escapeHtml(m.name)}</strong>
              <div class="model-badges">${badges.join("")}</div>
            </div>
          </div>
          <a class="model-key-link" href="${m.officialUrl}" target="_blank" rel="noopener noreferrer">${t("getKey")} ↗</a>
        </li>`;
    })
    .join("");
}

function openSettings() {
  updateAIStatusUI();
  populateModelSelect();
  // Usage line
  let note = $("#usage-note");
  if (!note) {
    note = document.createElement("p");
    note.id = "usage-note";
    note.className = "modal-note usage-note";
    $("#settings-modal .settings-panel")?.appendChild(note);
  }
  note.textContent = `${t("usageToday")} ${getUsageToday()}`;
  $("#settings-modal")?.classList.remove("hidden");
  document.body.style.overflow = "hidden";
}

function closeSettings() {
  $("#settings-modal")?.classList.add("hidden");
  document.body.style.overflow = "";
}

function showAIResult(ok, msg) {
  const box = $("#ai-test-result");
  if (!box) return;
  box.classList.remove("hidden");
  box.classList.toggle("ok", !!ok);
  box.classList.toggle("bad", !ok);
  box.textContent = msg;
}

async function onSaveAI() {
  const key = ($("#ai-key")?.value || "").trim();
  const modelId = $("#ai-model")?.value;
  const customModel = ($("#ai-custom-model")?.value || "").trim();
  if (!key || key.length < 8) {
    showAIResult(false, getLang() === "ar" ? "الصق مفتاح API صالحاً أولاً." : "Paste a valid API key first.");
    return;
  }
  initAIProvider({ apiKey: key, modelId, customModel });
  showAIResult(true, getLang() === "ar" ? "جارٍ اختبار الاتصال…" : "Testing connection…");
  const res = await testConnection();
  updateAIStatusUI();
  if (res.ok) {
    if ($("#ai-key")) $("#ai-key").value = "";
    showAIResult(true, t("connectionOk"));
    showToast(t("aiConnected"));
    setTimeout(closeSettings, 700);
  } else {
    clearAIProvider();
    updateAIStatusUI();
    showAIResult(false, `${t("connectionFail")}: ${res.error || ""}`);
  }
}

function onClearAI() {
  if (!confirm(t("clearAIConfirm"))) return;
  clearAIProvider();
  if ($("#ai-key")) $("#ai-key").value = "";
  updateAIStatusUI();
  updateModeBanner();
  showToast(t("aiDisconnected"));
}

async function onTestAI() {
  const key = ($("#ai-key")?.value || "").trim();
  const modelId = $("#ai-model")?.value;
  const customModel = ($("#ai-custom-model")?.value || "").trim();
  if (key.length > 8) initAIProvider({ apiKey: key, modelId, customModel });
  const btn = $("#btn-test-ai");
  if (btn) btn.disabled = true;
  showAIResult(true, getLang() === "ar" ? "جارٍ اختبار الاتصال…" : "Testing connection…");
  const res = await testConnection();
  if (btn) btn.disabled = false;
  showAIResult(res.ok, res.ok ? t("connectionOk") : `${t("connectionFail")}: ${res.error || ""}`);
  updateAIStatusUI();
}

function updateAIStatusUI() {
  const badge = $("#ai-status-badge");
  const status = getAIStatus();
  if (badge) {
    badge.textContent = status.available ? t("aiConnected") : t("aiDisconnected");
    badge.className = "ai-status " + (status.available ? "on" : "off");
  }
  updateModeBanner();
}

function updateModeBanner() {
  const el = $("#mode-banner");
  if (!el) return;
  if (isAIAvailable()) {
    el.textContent = t("modeBannerAI");
    el.className = "mode-banner ai-banner";
  } else {
    el.textContent = t("modeBannerOffline");
    el.className = "mode-banner offline-banner";
  }
}

// ── Examples ─────────────────────────────────────────────────────────────

function openExamples() {
  renderExamplesList();
  $("#examples-modal")?.classList.remove("hidden");
  document.body.style.overflow = "hidden";
}

function closeExamples() {
  $("#examples-modal")?.classList.add("hidden");
  document.body.style.overflow = "";
}

function renderExamplesList() {
  const list = $("#examples-list");
  if (!list) return;
  list.innerHTML = "";
  EXAMPLES.forEach((ex) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "example-item";
    btn.innerHTML = `<div class="ex-title">${t(ex.titleKey)}</div><div class="ex-desc">${t(ex.descKey)}</div>`;
    btn.addEventListener("click", () => {
      const lang = getLang();
      if ($("#input-text")) $("#input-text").value = ex.text[lang] || ex.text.ar;
      removeImage();
      closeExamples();
    });
    list.appendChild(btn);
  });
}

// ── About page ───────────────────────────────────────────────────────────

function updateSourceLabels() {
  const ar = getLang() === "ar";
  const set = (sel, v) => { const e = $(sel); if (e) e.textContent = v; };
  set("#btn-source", ar ? "📊 تقرير المصدر التفصيلي" : "📊 Detailed source report");
  set("#source-title", ar ? "تقرير المصدر التفصيلي" : "Detailed source report");
  set("#btn-source-back", ar ? "العودة للنتيجة" : "Back to result");
  set("#btn-source-new", ar ? "تحليل جديد" : "New analysis");
}

function openSourceReport() {
  const lang = getLang();
  updateSourceLabels();
  renderSourceReport($("#source-body"), { text: lastText, result: lastResult, lang });
  const lead = $("#source-lead");
  if (lead) lead.textContent = lang === "ar"
    ? "كل ما يمكن استنتاجه عن مصدر الخبر أو الرابط أو الحدث — بشفافية، مع بيان ما لا يمكن التحقق منه دون اتصال."
    : "Everything that can be inferred about the source — transparently, including what cannot be verified offline.";
  showView("source");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function openAbout() {
  showView("about");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// ── Voice input (Web Speech API) ─────────────────────────────────────────

let recognition = null;
let isListening = false;

function getSpeechRecognition() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return null;
  if (!recognition) {
    recognition = new SR();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.onresult = (event) => {
      let transcript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      const ta = $("#input-text");
      if (ta && transcript) {
        const cur = ta.value.trim();
        ta.value = cur ? cur + " " + transcript : transcript;
        ta.dispatchEvent(new Event("input", { bubbles: true }));
      }
    };
    recognition.onerror = (event) => {
      stopVoiceInput();
      const code = event?.error || "";
      if (code === "not-allowed" || code === "service-not-allowed") {
        showToast(t("micError"), true);
      } else if (code === "no-speech") {
        showToast(getLang() === "ar" ? "لم يُلتقط كلام — حاول مجدداً" : "No speech detected — try again", true);
      } else if (code !== "aborted") {
        showToast(t("micError"), true);
      }
    };
    recognition.onend = () => {
      stopVoiceInput();
    };
  }
  return recognition;
}

async function toggleVoiceInput() {
  if (isListening) {
    stopVoiceInput();
    return;
  }
  const rec = getSpeechRecognition();
  if (!rec) {
    showToast(t("micNotSupported"), true);
    return;
  }
  // Ensure mic permission when available
  if (navigator.mediaDevices?.getUserMedia) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((tr) => tr.stop());
    } catch (_) {
      showToast(t("micError"), true);
      return;
    }
  }
  rec.lang = getLang() === "ar" ? "ar-SA" : "en-US";
  try {
    rec.start();
    isListening = true;
    $("#btn-mic")?.classList.add("listening");
    showToast(t("micListening"));
  } catch (_) {
    showToast(t("micError"), true);
    isListening = false;
  }
}

function stopVoiceInput() {
  isListening = false;
  $("#btn-mic")?.classList.remove("listening");
  try {
    recognition?.stop();
  } catch (_) {}
}

// ── Theme (dark / light) ─────────────────────────────────────────────────

function initTheme() {
  let theme = "dark";
  try {
    theme = localStorage.getItem("trustai_theme") || "dark";
  } catch (_) {}
  applyTheme(theme);
}

function applyTheme(theme) {
  const isLight = theme === "light";
  document.documentElement.setAttribute("data-theme", isLight ? "light" : "dark");
  const moon = document.querySelector(".theme-icon-moon");
  const sun = document.querySelector(".theme-icon-sun");
  if (moon) moon.style.display = isLight ? "none" : "block";
  if (sun) sun.style.display = isLight ? "block" : "none";
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", isLight ? "#f1f5f9" : "#0a0f1a");
  try {
    localStorage.setItem("trustai_theme", theme);
  } catch (_) {}
}

function toggleTheme() {
  const current = document.documentElement.getAttribute("data-theme") || "dark";
  applyTheme(current === "light" ? "dark" : "light");
}

// ── PWA Install to desktop ───────────────────────────────────────────────

let deferredInstallPrompt = null;

function initInstallPrompt() {
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
    const btn = $("#btn-install");
    if (btn) {
      btn.classList.remove("hidden");
      btn.title = t("installHint");
    }
  });
  window.addEventListener("appinstalled", () => {
    deferredInstallPrompt = null;
    $("#btn-install")?.classList.add("hidden");
    showToast(t("installOk"));
  });
  // Already installed (standalone)
  if (window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone) {
    $("#btn-install")?.classList.add("hidden");
  }
}

async function triggerInstall() {
  if (!deferredInstallPrompt) {
    showToast(t("installHint"));
    return;
  }
  deferredInstallPrompt.prompt();
  try {
    const choice = await deferredInstallPrompt.userChoice;
    if (choice?.outcome === "accepted") {
      showToast(t("installOk"));
    }
  } catch (_) {}
  deferredInstallPrompt = null;
  $("#btn-install")?.classList.add("hidden");
}

// ── Share app (Web Share API — Android multi-share menu) ─────────────────

async function shareApp() {
  const url = window.location.href.split("?")[0].split("#")[0];
  const title = "TRUST AI";
  const text = getLang() === "ar"
    ? "تحقق قبل أن تثق — منصة موثوقة لتحليل الرسائل والروابط ضد الاحتيال"
    : "Verify before you trust — digital safety analysis for messages & links";
  if (navigator.share) {
    try {
      await navigator.share({ title, text, url });
      showToast(t("shareOk"));
      return;
    } catch (err) {
      if (err?.name === "AbortError") return;
    }
  }
  // Fallback: copy link
  try {
    await navigator.clipboard.writeText(url);
    showToast(getLang() === "ar" ? "تم نسخ الرابط ✓" : "Link copied ✓");
  } catch (_) {
    showToast(t("shareFail"), true);
  }
}

// ── History (local only) ─────────────────────────────────────────────────

function loadHistory() {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function saveToHistory(text, result) {
  try {
    const entry = {
      id: Date.now(),
      at: new Date().toISOString(),
      preview: (text || "").slice(0, 120),
      score: result.score,
      level: result.level,
      mode: result.mode || "offline",
    };
    const list = loadHistory().filter((e) => e.preview !== entry.preview);
    list.unshift(entry);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(list.slice(0, HISTORY_MAX)));
  } catch (_) {}
}

function openHistory() {
  const list = $("#history-list");
  if (!list) return;
  const items = loadHistory();
  if (!items.length) {
    list.innerHTML = `<li class="history-empty">${t("historyEmpty")}</li>`;
  } else {
    list.innerHTML = items.map((e) => {
      const date = e.at ? new Date(e.at).toLocaleString(getLang() === "ar" ? "ar" : "en") : "";
      const score = e.score < 0 ? "—" : e.score;
      return `<li class="history-item" data-id="${e.id}">
        <div class="history-item-main">
          <span class="history-score" style="color:${levelColor(e.level)}">${score}</span>
          <span class="history-level">${t("level_" + (e.level || "unknown"))}</span>
          <span class="history-date">${escapeHtml(date)}</span>
        </div>
        <p class="history-preview">${escapeHtml(e.preview || "")}</p>
      </li>`;
    }).join("");
  }
  $("#history-modal")?.classList.remove("hidden");
  document.body.style.overflow = "hidden";
}

function closeHistory() {
  $("#history-modal")?.classList.add("hidden");
  document.body.style.overflow = "";
}

function clearHistory() {
  if (!confirm(t("historyConfirmClear"))) return;
  try {
    localStorage.removeItem(HISTORY_KEY);
  } catch (_) {}
  openHistory();
  showToast(t("btnClearHistory"));
}

function levelColor(level) {
  return { low: "#22c55e", medium: "#eab308", high: "#f97316", severe: "#ef4444", unknown: "#94a3b8" }[level] || "#94a3b8";
}

// ── Copy / Share / Print result ──────────────────────────────────────────

function buildResultText() {
  if (!lastResult) return "";
  const r = lastResult;
  const lines = [
    "TRUST AI — " + (getLang() === "ar" ? "نتيجة التحليل" : "Analysis result"),
    "──────────────",
    `${t("riskScore")}: ${r.score < 0 ? "—" : r.score}/100`,
    `${t("resultTitle")}: ${t("level_" + r.level)}`,
    "",
  ];
  if (r.ai?.summary) {
    lines.push(t("aiSummary") + ":", r.ai.summary, "");
  }
  if (r.reasons?.length) {
    lines.push(t("whyTitle") + ":");
    r.reasons.forEach((k) => lines.push("• " + (t("reason_" + k) || k)));
    lines.push("");
  }
  if (r.actions?.length) {
    lines.push(t("actionTitle") + ":");
    r.actions.forEach((k) => lines.push("• " + (t("action_" + k) || k)));
    lines.push("");
  }
  if (r.links?.length) {
    lines.push(t("linksTitle") + ":");
    r.links.forEach((l) => lines.push(`• ${l.host || ""} (score ${l.score})`));
    lines.push("");
  }
  lines.push(t("disclaimer"));
  lines.push(window.location.href.split("?")[0]);
  return lines.join("\n");
}

async function copyResult() {
  const text = buildResultText();
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
    showToast(t("copyOk"));
  } catch (_) {
    showToast(t("shareFail"), true);
  }
}

async function shareResult() {
  const text = buildResultText();
  if (!text) return;
  if (navigator.share) {
    try {
      await navigator.share({
        title: "TRUST AI",
        text,
      });
      showToast(t("shareResultOk"));
      return;
    } catch (err) {
      if (err?.name === "AbortError") return;
    }
  }
  await copyResult();
}

function printResult() {
  window.print();
}

// ── Elderly / large text mode ────────────────────────────────────────────

function initElderly() {
  let on = false;
  try {
    on = localStorage.getItem("trustai_elderly") === "1";
  } catch (_) {}
  document.documentElement.classList.toggle("elderly", on);
}

function toggleElderly() {
  const on = !document.documentElement.classList.contains("elderly");
  document.documentElement.classList.toggle("elderly", on);
  try {
    localStorage.setItem("trustai_elderly", on ? "1" : "0");
  } catch (_) {}
  showToast(on ? t("elderlyOn") : t("elderlyOff"));
}

// ── Sensitive paste warning ──────────────────────────────────────────────

function bindSensitiveWatch() {
  const ta = $("#input-text");
  if (!ta) return;
  const run = () => {
    const hits = detectSensitivePaste(ta.value);
    const box = $("#sensitive-warn");
    if (!box) return;
    if (!hits.length) {
      box.classList.add("hidden");
      box.textContent = "";
      return;
    }
    const map = {
      otp: t("sensitiveWarnOtp"),
      card: t("sensitiveWarnCard"),
      iban: t("sensitiveWarnIban"),
      seed: t("sensitiveWarnSeed"),
      password: t("sensitiveWarnPassword"),
    };
    box.textContent = hits.map((h) => map[h] || "").filter(Boolean).join(" ");
    box.classList.remove("hidden");
  };
  ta.addEventListener("input", run);
  ta.addEventListener("paste", () => setTimeout(run, 30));
}

// ── Usage counter (local, approximate) ───────────────────────────────────

function bumpUsage() {
  try {
    const day = new Date().toISOString().slice(0, 10);
    const raw = localStorage.getItem(USAGE_KEY);
    let data = raw ? JSON.parse(raw) : { day, count: 0 };
    if (data.day !== day) data = { day, count: 0 };
    data.count += 1;
    localStorage.setItem(USAGE_KEY, JSON.stringify(data));
  } catch (_) {}
}

function getUsageToday() {
  try {
    const day = new Date().toISOString().slice(0, 10);
    const raw = localStorage.getItem(USAGE_KEY);
    const data = raw ? JSON.parse(raw) : null;
    if (!data || data.day !== day) return 0;
    return data.count || 0;
  } catch {
    return 0;
  }
}

// ── Views ────────────────────────────────────────────────────────────────

function showView(name) {
  $$(".view").forEach((v) => v.classList.remove("active"));
  const el = $(`#view-${name}`);
  if (el) el.classList.add("active");
}

function resetToHome() {
  lastResult = null;
  stopVoiceInput();
  setLiveAlertsIdle();
  showView("home");
}

// ── LIVE alert signal lights ─────────────────────────────────────────────
// Green = low/safe · Blue = monitoring/info · Orange = high · Red = severe

function clearLiveAlertClasses() {
  const group = $(".live-alerts");
  if (!group) return;
  group.classList.remove("idle", "has-high", "has-severe");
  $$(".alert-btn").forEach((btn) => btn.classList.remove("active"));
}

function setLiveAlertsIdle() {
  clearLiveAlertClasses();
  $(".live-alerts")?.classList.add("idle");
}

function setLiveAlertsMonitoring() {
  clearLiveAlertClasses();
  $("#alert-blue")?.classList.add("active");
}

/**
 * Map analysis level → glowing signal lights.
 * medium activates orange (warning), high → orange stronger, severe → red.
 * low → green. unknown → blue.
 */
function updateLiveAlerts(level, score) {
  clearLiveAlertClasses();
  const group = $(".live-alerts");
  if (!group) return;

  if (level === "severe" || (typeof score === "number" && score >= 75)) {
    $("#alert-red")?.classList.add("active");
    group.classList.add("has-severe");
  } else if (level === "high" || (typeof score === "number" && score >= 50)) {
    $("#alert-orange")?.classList.add("active");
    group.classList.add("has-high");
  } else if (level === "medium" || (typeof score === "number" && score >= 25)) {
    $("#alert-orange")?.classList.add("active");
  } else if (level === "low" || (typeof score === "number" && score >= 0 && score < 25)) {
    $("#alert-green")?.classList.add("active");
  } else {
    // unknown / insufficient data
    $("#alert-blue")?.classList.add("active");
  }
}

// ── Toast & utils ────────────────────────────────────────────────────────

let toastTimer = null;
function showToast(message, isError = false) {
  const toast = $("#toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.add("hidden"), 3500);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
