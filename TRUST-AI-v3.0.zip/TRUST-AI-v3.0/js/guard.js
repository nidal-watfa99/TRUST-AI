/* TRUST AI — early guard (classic script, runs before the app).
 * 1) Anti-clickjacking: GitHub Pages cannot send frame-ancestors / X-Frame-Options,
 *    so the page stays hidden (see <style id="anti-clickjack"> in index.html) and is
 *    only revealed when it is the top-level document.
 * 2) Marks that the guard ran so the self-check can report it honestly. */
(function () {
  "use strict";
  var framed = true;
  try { framed = window.top !== window.self; } catch (e) { framed = true; }
  if (!framed) {
    var s = document.getElementById("anti-clickjack");
    if (s && s.parentNode) s.parentNode.removeChild(s);
    window.__TRUST_GUARD__ = { framed: false };
  } else {
    window.__TRUST_GUARD__ = { framed: true };
    try { window.top.location = window.self.location; } catch (e) { /* cross-origin top: stay hidden */ }
  }
})();
