#!/usr/bin/env bash
# Finds the app folder to test/deploy and exports it as APP_DIR.
# If a TRUST-AI*.zip sits in the repo root, the NEWEST one is extracted into a clean
# folder and used on its own (no overlay on top of stale files from older versions).
set -euo pipefail

ZIP=$(ls -1 TRUST-AI*.zip 2>/dev/null | sort -V | tail -1 || true)

if [ -n "$ZIP" ]; then
  echo "Found archive: $ZIP"
  rm -rf _app
  mkdir _app
  unzip -q -o "$ZIP" -d _app
  APP_DIR=_app
  if [ ! -f "$APP_DIR/package.json" ]; then
    INNER=$(find _app -maxdepth 3 -name package.json -not -path '*/node_modules/*' | head -1 | xargs -r dirname)
    [ -n "$INNER" ] && APP_DIR="$INNER"
  fi
else
  echo "No archive found, using repository root"
  APP_DIR=.
fi

if [ ! -f "$APP_DIR/package.json" ] || [ ! -f "$APP_DIR/index.html" ]; then
  echo "::error::package.json / index.html not found in '$APP_DIR'"
  ls -la "$APP_DIR" || true
  exit 1
fi

echo "APP_DIR=$APP_DIR"
echo "APP_DIR=$APP_DIR" >> "$GITHUB_ENV"
